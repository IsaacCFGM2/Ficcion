/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.documentacion;

/**
 *
 * @author Isaac
 */
/**
 * Clase actor que hereda de persona
 * <p>Clase Actor</p>
 */
public class Actor extends Persona implements Id {
    /**
     * Variable con la url de la imagen
     */
    private String url;
    /**
     * Constructor de actor
     * @param nombre nombre del actor heredado desde persona
     * @param edad edad del actor heredado de persona
     * @param id id
     * @param url url de la imagen
     */
    public Actor(String nombre, int edad, int id, String url) {
        super(nombre, edad, id);
        this.url = url;
    }
    /**
     * Get que devuelve la url de la imagen
     * @return url
     */
    public String getUrl() {
        return url;
    }
    /**
     * Funcion que muestra todos los atributos
     */
    public void mostrar() {
        System.out.println("Nombre " + nombre);
        System.out.println("Duracion "+ edad);
        System.out.println("Id " + id);
    }
}
