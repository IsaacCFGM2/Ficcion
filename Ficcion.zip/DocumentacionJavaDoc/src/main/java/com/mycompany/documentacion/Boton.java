/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.documentacion;

import java.awt.*;
import javax.swing.JButton;

/**
 *
 * @author Isaac
 */
/**
 * Boton personalizado que hereda JButton
 */
public class Boton extends JButton {
    /**
     * Crea el boton personalizado
     * @param texto texto del boton
     */
    public Boton (String texto) {
        super(texto);
        /**
         * Cambia el color de fondo del boton al rojo y el color del texto a blanco
         */
        setBackground(new Color(229, 9, 20));
        setForeground(Color.WHITE);
    }
}
