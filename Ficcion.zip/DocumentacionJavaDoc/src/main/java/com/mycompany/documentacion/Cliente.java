/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.documentacion;

/**
 *
 * @author Isaac
 */
/**
 * Clase cliente que hereda de persona
 * <p>Clase Cliente</p>
 */
public class Cliente extends Persona implements Id {
    /**
     * Variable del tipo cliente
     */
    private TipoCliente tipo;
    /**
     * Enum con los diferentes tipos de cliente
     */
    public enum TipoCliente {
        Anuncios,
        Basico,
        Premium
    }
    /**
     * Variable con la url de la imagen
     */
    private String url;
    /**
     * Constructor de cliente
     * @param tipo tipo de cliente
     * @param nombre nombre heredado de persona
     * @param edad edad heredado de persona
     * @param id id
     * @param url url imagen
     */
    public Cliente(TipoCliente tipo, String nombre, int edad, int id, String url) {
        super(nombre, edad, id);
        this.tipo = tipo;
        this.url = url;
    }
    /**
     * Get que devuelve el tipo de cliente
     * @return tipo cliente
     */
    public TipoCliente getTipo() {
        return tipo;
    }
    /**
     * Get que devuelve la url de la imagen
     * @return url
     */
    public String getUrl() {
        return url;
    }
    /**
     * Set que cambia el tipo de cliente
     * @param tipo tipo cliente
     */
    public void setTipo(TipoCliente tipo) {
        this.tipo = tipo;
    }   
    /**
     * Funcion que muestra todos los atributos
     */
    public void mostrar() {
        System.out.println("Nombre " + nombre);
        System.out.println("Duracion "+ edad);
        System.out.println("Id " + id);
        System.out.println("Tipo " + tipo);
    }
}
