/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.documentacion;

import java.util.Scanner;

/**
 *
 * @author Isaac
 */
public class Documentacion {
    /**
     * Main que llama a las funciones de mostrar y crear
     * @param args main
     */
    public static void main(String[] args) {
        crear();
        mostrar();
        new JFrame().setVisible(true);
    }
    /**
     * Variables de los objetos fuera de la funcion de crear, para que la funcion de mostrar los pueda usar
     */
    static Pelicula p1;
    static Pelicula p2;
    static Actor a1;
    static Actor a2;
    static Cliente c1;
    static Cliente c2;
    static Serie s1;
    static Serie s2;
    /**
     * Funcion que crea objetos
     */     
    public static void crear() {
        p1 = new Pelicula(120, "Jurassic Park", 1, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBoyr1OEEOw3lfA-kOacziP_TjRqSLwh6ABQ&s");
        p2 = new Pelicula(130, "Alien", 2, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQF4udqOnGUck2fz-X_K0X_qhL6fzIv7MqyPw&s");
        a1 = new Actor("Sam Neil", 70, 1, "");
        a2 = new Actor("Emma Watson", 29, 2, "");
        c1 = new Cliente(Cliente.TipoCliente.Premium, "Isaac", 19, 1, "");
        c2 = new Cliente(Cliente.TipoCliente.Anuncios, "Pepe", 27, 2, "");
        s1 = new Serie(1, new int[]{8}, new int[]{20,20,20,20,20,20,20,20}, "Mandalorian", 1, "https://es.web.img3.acsta.net/pictures/19/08/23/15/39/2728562.jpg?coixp=49&coiyp=62");
        s2 = new Serie(2, new int[]{8,5}, new int[]{20,20,20,20,20,20,20,20,30,30,30,30,30}, "Stranger Things", 2, "https://images.ctfassets.net/4cd45et68cgf/22eaxyrfqLTOmD0ZgFJDX0/6d7b8a0f4c3130fd87c9921cbd11d180/image5.jpg?w=1200");
    }
    /**
     * Funcion que muestra los objetos
     */
    public static void mostrar() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Elije opcion (1-Pelicula, 2-Actor, 3-Cliente, 4-Serie)");
        int opcion = sc.nextInt();
        switch (opcion) {
            case 1:
                p1.mostrar();
                p2.mostrar();
                break;
            case 2:
                a1.mostrar();
                a2.mostrar();
                break;
            case 3:
                c1.mostrar();
                c2.mostrar();
                break;
            case 4:
                s1.mostrar();
                s2.mostrar();
                break;
        }
    }
}
