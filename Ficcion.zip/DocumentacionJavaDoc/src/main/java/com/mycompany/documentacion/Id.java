/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.documentacion;

/**
 *
 * @author Isaac
 */
/**
 * Interfaz del id
 * <p>Interfaz del id que es implementado por las clases que heredan</p>
 */
public interface Id {
    /**
     * Get que devuelve el id del objeto
     * @return id 
     */
    int getId();
    /**
     * Muestra id por pantalla
     */
    default void mostrarId() {
        System.out.println("Id " + getId());
    }
}
