/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.documentacion;

/**
 *
 * @author Isaac
 */

/**
 * Clase que guarda las peliculas que hereda de titulo
 * <p>Clase Pelicula</p>
 */
public class Pelicula extends Titulo implements Id {
    /**
     * Variable que guarda la duracion
     */
    private int duracion;
    /**
     * Variable con la url de la imagen
     */
    private String url;
    /**
     * Constructor de la clase
     * @param duracion duracion peli
     * @param nombre nombre peli
     * @param id id
     * @param url url de imagen
     */
    public Pelicula(int duracion, String nombre, int id, String url) {
        super(nombre, id);
        this.duracion = duracion;
        this.url = url;
    }
    /**
     * Get que devuelve la duracion
     * @return duracion
     */
    public int getDuracion() {
        return duracion;
    }
    /**
     * Get que devuelve la url de la imagen
     * @return url
     */
    public String getUrl() {
        return url;
    }
    /**
     * Set que cambia la duracion
     * @param duracion duracion
     */
    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    /**
     * Funcion que muestra todos los atributos
     */
    public void mostrar() {
        System.out.println("Nombre " + nombre);
        System.out.println("Duracion "+ duracion);
        System.out.println("Id " + id);
    }
}
