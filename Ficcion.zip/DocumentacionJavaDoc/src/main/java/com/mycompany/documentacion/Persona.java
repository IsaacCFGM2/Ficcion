/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.documentacion;

/**
 *
 * @author Isaac
 */

/**
 * Clase Persona
 * <p>Clase Persona</p>
 */
public class Persona {
    /**
     * Variable nombre de persona
     */
    String nombre;
    /**
     * Variable edad de la persona
     */
    int edad;
    /**
     * Variable id
     */
    int id;
    /**
     * Constructor de persona
     * @param nombre nombre de la persona
     * @param edad edad de la persona
     * @param id id
     */
    public Persona(String nombre, int edad, int id) {
        this.nombre = nombre;
        this.edad = edad;
        this.id = id;
    }
    /**
     * Get que devuelve el nombre
     * @return nombre
     */
    public String getNombre() {
        return nombre;
    }
    /**
     * Set que actualiza el nombre
     * @param nombre nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /**
     * Get que devuelve la edad
     * @return edad
     */
    public int getEdad() {
        return edad;
    }
    /**
     * Set que actualiza la edad
     * @param edad edad
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }
    /**
     * Get que devuelve id
     * @return id
     */
    public int getId() {
        return id;
    }
    
}
