/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.documentacion;

/**
 *
 * @author Isaac
 */

/**
 * Clase Serie que hereda de titulo
 * <p>Clase Serie</p>
 */
public class Serie extends Titulo implements Id {
    /**
     * Variable con el numero de temporadas
     */
    private int numerotemp;
    /**
     * Array con la cantidad de eps por temporadas
     */
    private int[] capitulostemp;
    /**
     * Array con la duracion de cada capitulo
     */
    private int[] duracioncaps;
    /**
     * Variable con la url de la imagen
     */
    private String url;
    /**
     * Constructor de serie
     * @param numerotemp num temporadas
     * @param capitulostemp capitulos por temporadas
     * @param duracioncaps duracion de los capitulos de la temporada
     * @param nombre nombre de la serie
     * @param id id
     * @param url url de la imagen
     */
    public Serie(int numerotemp, int[] capitulostemp, int[] duracioncaps, String nombre, int id, String url) {
        super(nombre, id);
        this.numerotemp = numerotemp;
        this.capitulostemp = capitulostemp;
        this.duracioncaps = duracioncaps;
        this.url = url;
    }
    /**
     * Get que devuelve el num de temporadas
     * @return numero temporada
     */
    public int getNumerotemp() {
        return numerotemp;
    }
    /**
     * Get que devuelve el array con los capitulos por temporada
     * @return capitulos por temporada
     */
    public int[] getCapitulostemp() {
        return capitulostemp;
    }
    /**
     * Get que devuelve el array con la duracion de los caps
     * @return duracion capitulos
     */
    public int[] getDuracioncaps() {
        return duracioncaps;
    }
    /**
     * Get que devuelve la url de la imagen
     * @return url
     */
    public String getUrl() {
        return url;
    }
    /**
     * Funcion que recorre todas las temporadas, y multiplica los episodios de esa temporada por su duracion, y los guarda
     * en la variable suma que luego devuelve
     * @return duracion total
     */
    public int duracionTotal() {
        int suma = 0;
        for (int i = 0; i < numerotemp; i++) {
            suma += capitulostemp[i] * duracioncaps[i];
        }
        return suma;
        
    }
    /**
     * Funcion que muestra todos los atributos
     */
    public void mostrar() {
        System.out.println("Nombre " + nombre);
        System.out.println("Id " + id);
        System.out.println("Numero Temporadas " + numerotemp);
        System.out.println("Capitulos por Temp ");
        for (int i = 1; i<capitulostemp.length; i++) {
            System.out.println("capitulo " + capitulostemp[i]);
        }
        System.out.println("Duracion Capitulos ");
        for (int i = 1; i<duracioncaps.length; i++) {
            System.out.println("duracion " + duracioncaps[i]);
        }
    }
    
}
