/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.documentacion;

/**
 *
 * @author Isaac
 */
/**
 * Clase titulo
 * <p>Clase Titulo</p>
 */
public class Titulo {
    /**
     * Variable nombre
     */
    String nombre;
    /**
     * Variable id
     */
    int id;
    /**
     * Constructor de titulo
     * @param nombre nombre de la peli/serie
     * @param id id
     */
    public Titulo(String nombre, int id) {
        this.nombre = nombre;
        this.id = id;
    }
    /**
     * Get que devuelve el nombre
     * @return nombre
     */
    public String getNombre() {
        return nombre;
    }
    /**
     * Set que cambia el nombre
     * @param nombre nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /**
     * Get que devuelve id
     * @return id
     */
    public int getId() {
        return id;
    }
    
}
